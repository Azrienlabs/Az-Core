"""
ReactAgent implementation - exported for convenience.

This module re-exports the ReactAgent class from agent_factory.
"""

from arc_flow.agents.agent_factory import ReactAgent

__all__ = ["ReactAgent"]
