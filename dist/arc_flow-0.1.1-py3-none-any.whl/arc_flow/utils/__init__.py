"""
Utilities and helper functions for the Arc flow.

This module provides logging setup, prompt loading, decorators,
caching, conversation management, agent persistence, and other utility functions.
"""

from arc_flow.utils.logging import setup_logging, get_logger
from arc_flow.utils.prompts import PromptLoader, load_prompt
from arc_flow.utils.decorators import async_to_sync, sync_to_async
from arc_flow.utils.helpers import validate_state, clean_json
from arc_flow.utils.caching import (
    LRUCache,
    TTLCache,
    SemanticCache,
    PersistentCache,
    cached,
    get_llm_cache,
    get_embedding_cache,
    get_state_cache,
    clear_all_caches,
    get_all_cache_stats
)
from arc_flow.utils.cached_llm import CachedLLM, create_cached_llm, enable_llm_caching
from arc_flow.utils.conversation import Conversation
from arc_flow.utils.base_structure import BaseStructure
from arc_flow.utils.agent_persistence import AgentPersistence
from arc_flow.utils.output_formatter import (
    OutputType,
    history_output_formatter,
    format_conversation_history,
    format_agent_output,
    format_swarm_output,
    format_error_output,
    aggregate_outputs,
    format_to_json,
    format_execution_summary
)

__all__ = [
    # Logging
    "setup_logging",
    "get_logger",
    # Prompts
    "PromptLoader",
    "load_prompt",
    # Decorators
    "async_to_sync",
    "sync_to_async",
    # Helpers
    "validate_state",
    "clean_json",
    # Caching
    "LRUCache",
    "TTLCache",
    "SemanticCache",
    "PersistentCache",
    "cached",
    "get_llm_cache",
    "get_embedding_cache",
    "get_state_cache",
    "clear_all_caches",
    "get_all_cache_stats",
    # Cached LLM
    "CachedLLM",
    "create_cached_llm",
    "enable_llm_caching",
    # Conversation & Persistence
    "Conversation",
    "BaseStructure",
    "AgentPersistence",
    # Output Formatting (NEW)
    "OutputType",
    "history_output_formatter",
    "format_conversation_history",
    "format_agent_output",
    "format_swarm_output",
    "format_error_output",
    "aggregate_outputs",
    "format_to_json",
    "format_execution_summary",
]
